package com.example.tp3.Entites

import java.time.Month
import java.util.*

data class Paiement(
    var id_paiement:Int,
    var montant:Double,
    var date_paiement:Date

)
