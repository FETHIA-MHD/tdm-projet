package com.example.tp3.Entites

import androidx.room.Entity
data class Place(
    var numero_place:Int,
    var etat:Boolean,
    var id_parking:Int
)
